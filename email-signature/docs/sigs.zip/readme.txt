Thanks for downloading this. You're free to use these templates in whatever
context you want.

How to use:
    Open index.html in a text editor, don't use Word, use Atom or Sublime.
    Swap out your info for the sig you want
    To change the picture, go to /img and change the avatar.jpg image
    Open index.html in a browser and c/p it into your email signature

If you have any questions feel free to reach out to me:
johnphammail@gmail.com

